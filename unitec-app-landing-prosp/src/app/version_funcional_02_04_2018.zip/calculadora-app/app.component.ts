import { Component, OnInit } from '@angular/core';

import { UserService,User } from './shared';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
}) 
export class AppComponent implements OnInit {
  constructor (
    private userService: UserService,
   // user: User = {} as User;

  ) {}

  ngOnInit() {
     var user = {username:"aas",email:"test",token:"dsds",bio:"a",image:"",estado:"",linea:""};

    this.userService.populate(user);
  }
}

