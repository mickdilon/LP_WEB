import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mini-simulador',
  templateUrl: './mini-simulador.component.html',
  styleUrls: ['./mini-simulador.component.scss']
})
export class MiniSimuladorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
