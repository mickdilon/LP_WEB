import { Component } from '@angular/core';


@Component({
    selector: 'frm-problemas-cuenta',
    templateUrl: './frm-problemas-cuenta.component.html',
    styleUrls: [ './frm-problemas-cuenta.component.scss' ]
})

export class frmProblemasCuenta {

}