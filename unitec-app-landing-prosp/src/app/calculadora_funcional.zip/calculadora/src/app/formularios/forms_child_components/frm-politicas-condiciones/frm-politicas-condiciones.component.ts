import { Component } from '@angular/core';


@Component({
    selector: 'frm-politicas-condiciones',
    templateUrl: './frm-politicas-condiciones.component.html',
    styleUrls: [ './frm-politicas-condiciones.component.scss' ]
})

export class frmPoliticasCondiciones {

}