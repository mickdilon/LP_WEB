import { Injectable } from '@angular/core';

declare let jQuery: any;

@Injectable()

export class GenericService {

    constructor() {}
    //Validar si una imagen existe
    checkImage( url )
    {
    }

    //Funcion que emula get de php
    getMethod(param = "") {
        console.log("param passed" + param);
        if ( param != "" ) {
            console.log("SI trae parametro " + param);
            return vars[param.toLowerCase()] ? vars[param.toLowerCase()] : null;    
        }
                var vars = {};
                window.location.href.replace( location.hash, '' ).replace(/[?&]+([^=&]+)=?([^&]*)?/gi,function ( m, key, value ):any { 
                        vars[key.toLowerCase()] = value !== undefined ? value : '';
                }
                );
                return vars;
    }
}
