import { ModuleWithProviders, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule, JsonpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http'
import { AppComponent } from './app.component';
import { HomeModule } from './home/home.module';
import { ModalidadModule } from './modalidad/modalidad.module';
import { EstadoModule } from './estado/estado.module';
import { ResultadoModule } from './resultado/resultado.module';
import { CampusModule } from './campus/campus.module';
import { LineaModule } from './linea/linea.module';
import { OfertaModule } from './oferta/oferta.module';
import { NouisliderModule } from 'ng2-nouislider'; //add this!!!!!!
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule, FormsModule     } from '@angular/forms';
//Servicios
import { getJson } from "./shared/services/getJson.service";
import { DatosService } from "./shared/services/datos.service";
import { CookieService } from 'ngx-cookie-service';
import {UserService} from './shared/services/user.service';
import {ApiService} from './services/api.service';
import {JwtService} from './shared/services/jwt.service';
//import {ApiService} from './shared/services/api.service';
//Componentes padre
//import { formularioTradicionalComponent } from './formularios/forms_parent_components/formulario-tradicional/formulario-tradicional.component';
//Componentes hijo del formulario
//const rootRouting: ModuleWithProviders = RouterModule.forRoot([]);
const routes: Routes = [

];
@NgModule({
  declarations: [
    AppComponent,],
  imports: [
    BrowserModule,
    HomeModule, 
    //rootRouting,
    EstadoModule,
    RouterModule.forRoot(routes, { useHash: true }),  
    CampusModule,
    LineaModule,
    ResultadoModule,
    OfertaModule,
    ModalidadModule,
    NouisliderModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    JsonpModule,
    CommonModule,
    HttpClientModule
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    DatosService,
    CookieService,
    getJson,
    UserService,
    ApiService,
    JwtService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
