import { ModuleWithProviders, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NouisliderModule } from 'ng2-nouislider';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ResultadoComponent } from './../resultado/resultado.component';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from "@angular/common";
import { HttpClientModule } from '@angular/common/http'; 
import { HttpModule } from '@angular/http';
//Servicios
import { getJson } from "../shared/services/getJson.service";
import { DatosService } from "../shared/services/datos.service";
import { CookieService } from 'ngx-cookie-service';
import {UserService} from '../shared/services/user.service';
import {ApiService} from '../services/api.service';
import {JwtService} from '../shared/services/jwt.service';

const ResultadoRouting: ModuleWithProviders = RouterModule.forChild([
  {
    path: 'resultado',
    component: ResultadoComponent
  }
]);

@NgModule({ 
  imports: [
    ResultadoRouting,
    NouisliderModule,
    FormsModule, ReactiveFormsModule,BrowserModule,CommonModule,HttpClientModule,HttpModule 
  ],
  declarations: [
    ResultadoComponent
  ],
  providers: [
    DatosService,
    CookieService,
    getJson,
    UserService,
    ApiService,
    JwtService
  ],
})
export class ResultadoModule { }
