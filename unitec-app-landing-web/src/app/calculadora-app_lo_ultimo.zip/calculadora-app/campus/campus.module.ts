import { ModuleWithProviders, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CampusComponent } from './../campus/campus.component';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from "@angular/common";
import { HttpClientModule } from '@angular/common/http'; 
import { HttpModule } from '@angular/http';
//Servicios
import { getJson } from "../shared/services/getJson.service";
import { DatosService } from "../shared/services/datos.service";
import { CookieService } from 'ngx-cookie-service';
import {UserService} from '../shared/services/user.service';
import {ApiService} from '../services/api.service';
import {JwtService} from '../shared/services/jwt.service';


const estadoRouting: ModuleWithProviders = RouterModule.forChild([
  {
    path: 'campus',
    component: CampusComponent
  }
]);

@NgModule({ 
  imports: [
    estadoRouting,
    FormsModule, ReactiveFormsModule,BrowserModule,CommonModule,HttpClientModule,HttpModule
  ],
  declarations: [
    CampusComponent
  ],
  providers: [
    DatosService,
    CookieService,
    getJson,
    UserService,
    ApiService,
    JwtService
  ],
})
export class CampusModule { }
