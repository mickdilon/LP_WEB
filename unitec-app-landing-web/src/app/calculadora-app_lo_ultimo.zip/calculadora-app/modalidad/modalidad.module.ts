import { ModuleWithProviders, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalidadComponent } from './../modalidad/modalidad.component';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from "@angular/common";
import { HttpClientModule } from '@angular/common/http';
//Servicios
import { getJson } from "../shared/services/getJson.service";
import { DatosService } from "../shared/services/datos.service";
import { CookieService } from 'ngx-cookie-service';
import {UserService} from '../shared/services/user.service';
import {ApiService} from '../services/api.service';
import {JwtService} from '../shared/services/jwt.service';

const ModalidadRouting: ModuleWithProviders = RouterModule.forChild([
  {
    path: 'modalidad',
    component: ModalidadComponent
  }
]);

@NgModule({
  imports: [
    ModalidadRouting,
    FormsModule, ReactiveFormsModule,BrowserModule,CommonModule,HttpClientModule,HttpModule
  ],
  declarations: [
    ModalidadComponent
  ],
  providers: [
    DatosService,
    CookieService,
    getJson,
    UserService,
    ApiService,
    JwtService
  ],
})
export class ModalidadModule { }
