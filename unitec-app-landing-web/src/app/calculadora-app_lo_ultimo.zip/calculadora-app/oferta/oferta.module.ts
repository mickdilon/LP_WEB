import { ModuleWithProviders, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OfertaComponent } from './../oferta/oferta.component';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from "@angular/common";
import { HttpClientModule } from '@angular/common/http'; 
//Servicios
import { getJson } from "../shared/services/getJson.service";
import { DatosService } from "../shared/services/datos.service";
import { CookieService } from 'ngx-cookie-service';
import {UserService} from '../shared/services/user.service';
import {ApiService} from '../services/api.service';
import {JwtService} from '../shared/services/jwt.service';

const ofertaRouting: ModuleWithProviders = RouterModule.forChild([
  {
    path: 'oferta',
    component: OfertaComponent
  }
]);

@NgModule({
  imports: [
    ofertaRouting,
    FormsModule, ReactiveFormsModule,BrowserModule,CommonModule,HttpClientModule,HttpModule 
  ],
  declarations: [
    OfertaComponent
  ],
  providers: [
    DatosService,
    CookieService,
    getJson,
    UserService,
    ApiService,
    JwtService
  ],
})
export class OfertaModule { }
